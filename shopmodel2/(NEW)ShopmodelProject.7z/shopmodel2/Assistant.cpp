#include "Assistant.h"



Assistant::Assistant() : Seller()
{

}


Assistant::~Assistant()
{
}
