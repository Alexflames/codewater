#pragma once
#include <SFML\System\Time.hpp>

class Person
{
private:

public:
	Person();
	~Person();
};

