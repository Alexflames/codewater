#pragma once
#include "Seller.h"
class Assistant : public Seller
{
public:
	Assistant();
	~Assistant();
};

