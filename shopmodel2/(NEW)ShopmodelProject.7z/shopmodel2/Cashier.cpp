#include "Cashier.h"

Cashier::Cashier() : Seller()
{

}


Cashier::~Cashier()
{
}
