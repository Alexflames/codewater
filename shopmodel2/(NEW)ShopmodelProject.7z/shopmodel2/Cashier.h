#pragma once
#include "Seller.h"

class Cashier : public Seller
{
public:
	Cashier();
	~Cashier();


};

