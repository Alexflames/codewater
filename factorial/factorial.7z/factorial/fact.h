#pragma once
long long fact(int N);