#include "deepwaterFish.h"

DeepWaterFish::DeepWaterFish(string species, int age) : PredatorFish(species, age)
{
	
}
