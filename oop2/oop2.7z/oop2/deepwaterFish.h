#pragma once
#include "predatorFish.h"

class DeepWaterFish : public PredatorFish
{
public:
	DeepWaterFish(string species, int age);
};